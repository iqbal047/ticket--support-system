package com.iqbal.ticket_support_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicketSupportSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
