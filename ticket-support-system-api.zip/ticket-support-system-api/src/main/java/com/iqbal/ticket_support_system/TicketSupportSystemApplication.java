package com.iqbal.ticket_support_system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TicketSupportSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(TicketSupportSystemApplication.class, args);
	}

}
